package com.veyselseker.stitchstudio.engine

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

class PdfEngine {
    private val pageW = 595
    private val pageH = 842

    fun render(p: PatternResult, out: File) {
        val doc = PdfDocument()
        cover(doc, p)
        charts(doc, p)
        key(doc, p)
        readme(doc, p)
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    private fun newPage(doc: PdfDocument): Pair<PdfDocument.Page, Canvas> {
        val info = PdfDocument.PageInfo.Builder(pageW, pageH, doc.pages.size + 1).create()
        val page = doc.startPage(info)
        return page to page.canvas
    }

    private fun header(c: Canvas, title: String, sub: String) {
        val bar = Paint().apply { color = Color.parseColor("#1B1B2F"); style = Paint.Style.FILL }
        c.drawRect(0f, 0f, pageW.toFloat(), 52f, bar)
        val gold = Paint().apply { color = Color.parseColor("#C9A227"); style = Paint.Style.FILL }
        c.drawRect(0f, 52f, pageW.toFloat(), 56f, gold)
        val t = Paint().apply { color = Color.WHITE; textSize = 12f; isFakeBoldText = true }
        c.drawText("VEYSEL SEKER  ·  Cross Stitch", 28f, 24f, t)
        val s = Paint().apply { color = Color.parseColor("#C9A227"); textSize = 10f }
        c.drawText(title.take(48), 28f, 42f, s)
        c.drawText(sub.take(40), pageW - 200f, 24f, Paint().apply { color = Color.WHITE; textSize = 9f })
    }

    private fun footer(c: Canvas, n: Int) {
        val bar = Paint().apply { color = Color.parseColor("#1B1B2F") }
        c.drawRect(0f, pageH - 28f, pageW.toFloat(), pageH.toFloat(), bar)
        c.drawText("Personal use · Page $n", 28f, pageH - 10f, Paint().apply { color = Color.WHITE; textSize = 9f })
    }

    private fun cover(doc: PdfDocument, p: PatternResult) {
        val (page, c) = newPage(doc)
        c.drawRect(0f, 0f, pageW.toFloat(), pageH.toFloat(), Paint().apply { color = Color.parseColor("#141422") })
        val gold = Paint().apply { color = Color.parseColor("#C9A227"); style = Paint.Style.STROKE; strokeWidth = 2f }
        c.drawRect(24f, 24f, pageW - 24f, pageH - 24f, gold)
        c.drawText("DIGITAL CROSS STITCH PATTERN", 120f, 70f, Paint().apply { color = Color.parseColor("#C9A227"); textSize = 12f })
        c.drawText(p.title.take(36), 60f, 110f, Paint().apply { color = Color.WHITE; textSize = 22f; isFakeBoldText = true })
        val pw = 280
        val ph = (p.preview.height.toFloat() / p.preview.width * pw).toInt().coerceAtMost(320)
        val left = (pageW - pw) / 2f
        val top = 150f
        c.drawBitmap(p.preview, null, RectF(left, top, left + pw, top + ph), null)
        val (wi, hi) = p.sizeInches()
        val (wc, hc) = p.sizeCm()
        val body = Paint().apply { color = Color.parseColor("#E8E0C8"); textSize = 12f }
        var y = top + ph + 40
        listOf(
            "${p.width} x ${p.height} stitches",
            "${p.colorCount} DMC colours",
            "${p.aida}-count  ${"%.1f".format(wi)}\" x ${"%.1f".format(hi)}\"  (${"%.1f".format(wc)} x ${"%.1f".format(hc)} cm)"
        ).forEach {
            c.drawText(it, 80f, y, body)
            y += 20
        }
        c.drawText("VEYSEL SEKER", 220f, pageH - 50f, Paint().apply { color = Color.parseColor("#C9A227"); textSize = 12f })
        doc.finishPage(page)
    }

    private fun charts(doc: PdfDocument, p: PatternResult) {
        val cx = 30
        val cy = 38
        val overlap = 3
        val stepY = cy - overlap
        val cols = (p.width + cx - 1) / cx
        val rows = if (p.height <= cy) 1 else 1 + (p.height - cy + stepY - 1) / stepY
        val pal = p.palette.associateBy { it.code }
        val cell = 14f
        val left = 36f
        val top = 80f
        var n = 2
        for (ry in 0 until rows) {
            val y0 = if (ry == 0) 0 else ry * stepY
            val y1 = minOf(p.height, y0 + cy)
            for (rx in 0 until cols) {
                val x0 = rx * cx
                val x1 = minOf(p.width, x0 + cx)
                val (page, c) = newPage(doc)
                c.drawRect(0f, 0f, pageW.toFloat(), pageH.toFloat(), Paint().apply { color = Color.WHITE })
                header(c, p.title, "Chart ${rx + 1},${ry + 1}")
                val fill = Paint()
                val text = Paint().apply { textSize = 7f; textAlign = Paint.Align.CENTER }
                for (yy in y0 until y1) {
                    for (xx in x0 until x1) {
                        val code = p.grid[yy][xx]
                        val col = pal[code]
                        fill.color = col?.colorInt ?: Color.LTGRAY
                        val px = left + (xx - x0) * cell
                        val py = top + (yy - y0) * cell
                        c.drawRect(px, py, px + cell, py + cell, fill)
                        val lum = if (col == null) 128 else (col.r * 299 + col.g * 587 + col.b * 114) / 1000
                        text.color = if (lum < 140) Color.WHITE else Color.BLACK
                        c.drawText(p.symbols[code] ?: "?", px + cell / 2, py + cell * 0.72f, text)
                    }
                }
                val line = Paint().apply { color = Color.DKGRAY; strokeWidth = 0.4f }
                val bold = Paint().apply { color = Color.BLACK; strokeWidth = 1.2f }
                for (i in 0..(x1 - x0)) {
                    val x = left + i * cell
                    c.drawLine(x, top, x, top + (y1 - y0) * cell, if (i % 10 == 0) bold else line)
                }
                for (j in 0..(y1 - y0)) {
                    val y = top + j * cell
                    c.drawLine(left, y, left + (x1 - x0) * cell, y, if (j % 10 == 0) bold else line)
                }
                footer(c, n++)
                doc.finishPage(page)
            }
        }
    }

    private fun key(doc: PdfDocument, p: PatternResult) {
        val (page, c) = newPage(doc)
        c.drawRect(0f, 0f, pageW.toFloat(), pageH.toFloat(), Paint().apply { color = Color.WHITE })
        header(c, p.title, "DMC Colour Key")
        val cols = 4
        val colW = 130f
        val rowH = 22f
        p.palette.forEachIndexed { i, col ->
            val ci = i % cols
            val ri = i / cols
            val x = 28f + ci * colW
            val y = 80f + ri * rowH
            c.drawRect(x, y, x + 16f, y + 14f, Paint().apply { color = col.colorInt })
            c.drawText("${p.symbols[col.code]} ${col.code}  ${p.counts[col.code]}", x + 20f, y + 12f,
                Paint().apply { color = Color.BLACK; textSize = 8f })
        }
        footer(c, doc.pages.size + 1)
        doc.finishPage(page)
    }

    private fun readme(doc: PdfDocument, p: PatternResult) {
        val (page, c) = newPage(doc)
        c.drawRect(0f, 0f, pageW.toFloat(), pageH.toFloat(), Paint().apply { color = Color.WHITE })
        header(c, p.title, "How to stitch")
        val t = Paint().apply { color = Color.BLACK; textSize = 11f }
        val lines = listOf(
            "Design: ${p.title}",
            "Grid: ${p.width} x ${p.height} on ${p.aida}-count Aida.",
            "Use 2 strands. Each square is one full cross.",
            "Bold lines mark every 10 stitches.",
            "Start from the centre of the fabric.",
            "Personal use only. Tesekkurler — Veysel Seker"
        )
        var y = 90f
        lines.forEach {
            c.drawText(it, 36f, y, t)
            y += 22f
        }
        footer(c, doc.pages.size + 1)
        doc.finishPage(page)
    }
}
