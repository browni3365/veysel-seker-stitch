package com.veyselseker.stitchstudio.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min
import kotlin.math.sin

class MockupEngine {
    fun renderAll(p: PatternResult, dir: File): List<File> {
        dir.mkdirs()
        val stitch = xStitch(p, 8)
        val files = mutableListOf<File>()
        files += save(dir, "01_round_hoop.png", hoop(stitch, p.title))
        files += save(dir, "02_etsy_hero.png", hero(stitch, p))
        return files
    }

    private fun save(dir: File, name: String, bmp: Bitmap): File {
        val f = File(dir, name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 92, it) }
        return f
    }

    private fun xStitch(p: PatternResult, scale: Int): Bitmap {
        val w = p.width * scale
        val h = p.height * scale
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.rgb(246, 239, 226))
        val pal = p.palette.associateBy { it.code }
        val paint = Paint().apply { strokeWidth = (scale / 3f).coerceAtLeast(2f); isAntiAlias = true }
        for (y in 0 until p.height) {
            for (x in 0 until p.width) {
                val col = pal[p.grid[y][x]] ?: continue
                paint.color = col.colorInt
                val x0 = x * scale + 1f
                val y0 = y * scale + 1f
                val x1 = (x + 1) * scale - 1f
                val y1 = (y + 1) * scale - 1f
                c.drawLine(x0, y0, x1, y1, paint)
                c.drawLine(x0, y1, x1, y0, paint)
            }
        }
        return bmp
    }

    private fun wood(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pix = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val wave = sin(x / 28.0 + sin(y / 40.0) * 2) * 18
                val v = (118 + wave).toInt().coerceIn(40, 200)
                pix[y * w + x] = Color.rgb(v + 40, v + 12, (v - 20).coerceAtLeast(0))
            }
        }
        bmp.setPixels(pix, 0, w, 0, 0, w, h)
        return bmp
    }

    private fun hoop(stitch: Bitmap, title: String): Bitmap {
        val s = 1000
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(wood(s, s), 0f, 0f, null)
        val side = 720
        val st = Bitmap.createScaledBitmap(stitch, side, side, false)
        val cx = s / 2f
        val cy = s / 2f - 20
        val path = android.graphics.Path().apply {
            addCircle(cx, cy, side / 2f, android.graphics.Path.Direction.CW)
        }
        c.save()
        c.clipPath(path)
        c.drawBitmap(st, cx - side / 2f, cy - side / 2f, null)
        c.restore()
        val ring = Paint().apply { style = Paint.Style.STROKE; isAntiAlias = true }
        ring.color = Color.rgb(90, 50, 20)
        ring.strokeWidth = 36f
        c.drawCircle(cx, cy, side / 2f + 10, ring)
        ring.color = Color.rgb(160, 110, 55)
        ring.strokeWidth = 10f
        c.drawCircle(cx, cy, side / 2f - 8, ring)
        c.drawText(title.take(28), 80f, 960f, Paint().apply { color = Color.rgb(40, 32, 24); textSize = 28f; isFakeBoldText = true })
        return out
    }

    private fun hero(stitch: Bitmap, p: PatternResult): Bitmap {
        val w = 1600
        val h = 1200
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.parseColor("#181826"))
        val gold = Paint().apply { color = Color.parseColor("#C9A227") }
        c.drawRect(0f, 0f, w.toFloat(), 16f, gold)
        c.drawRect(0f, h - 16f, w.toFloat(), h.toFloat(), gold)
        val hoop = hoop(stitch, "")
        c.drawBitmap(Bitmap.createScaledBitmap(hoop, 780, 780, true), 60f, 200f, null)
        val t = Paint().apply { color = Color.parseColor("#C9A227"); textSize = 28f }
        c.drawText("CROSS STITCH", 980f, 260f, t)
        c.drawText(p.title.take(24), 980f, 330f, Paint().apply { color = Color.WHITE; textSize = 40f; isFakeBoldText = true })
        val (wi, hi) = p.sizeInches()
        val body = Paint().apply { color = Color.parseColor("#E6E0D2"); textSize = 26f }
        var y = 430f
        listOf(
            "${p.width} x ${p.height} stitches",
            "${p.colorCount} DMC colours",
            "${p.aida}-count  ${"%.1f".format(wi)}\" x ${"%.1f".format(hi)}\"",
            "Instant PDF download"
        ).forEach {
            c.drawText(it, 980f, y, body)
            y += 50f
        }
        c.drawRoundRect(RectF(980f, 720f, 1420f, 800f), 12f, 12f, gold)
        c.drawText("DIGITAL PATTERN", 1010f, 772f, Paint().apply { color = Color.parseColor("#181826"); textSize = 24f; isFakeBoldText = true })
        return out
    }
}
