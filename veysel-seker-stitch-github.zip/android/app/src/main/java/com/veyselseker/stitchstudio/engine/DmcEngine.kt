package com.veyselseker.stitchstudio.engine

import android.content.Context
import org.json.JSONArray
import kotlin.math.min

data class DmcColor(val code: String, val name: String, val hex: String, val r: Int, val g: Int, val b: Int) {
    val colorInt: Int get() = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
}

class DmcEngine(context: Context) {
    val colors: List<DmcColor>

    init {
        val json = context.assets.open("dmc_colors.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(json)
        val list = ArrayList<DmcColor>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val hex = o.getString("hex").trim().removePrefix("#")
            val rgb = hex.toInt(16)
            list.add(
                DmcColor(
                    o.getString("code"),
                    o.getString("name"),
                    "#$hex",
                    (rgb shr 16) and 0xFF,
                    (rgb shr 8) and 0xFF,
                    rgb and 0xFF
                )
            )
        }
        colors = list
    }

    fun nearest(r: Int, g: Int, b: Int): DmcColor {
        var best = colors[0]
        var bestD = Long.MAX_VALUE
        for (c in colors) {
            val dr = (r - c.r).toLong()
            val dg = (g - c.g).toLong()
            val db = (b - c.b).toLong()
            val d = dr * dr + dg * dg + db * db
            if (d < bestD) {
                bestD = d
                best = c
            }
        }
        return best
    }

    fun symbolsFor(codes: List<String>): Map<String, String> {
        val glyphs = "●○■□▲△◆◇★☆✚✕✱ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return codes.mapIndexed { i, code -> code to glyphs[i % glyphs.length].toString() }.toMap()
    }
}
