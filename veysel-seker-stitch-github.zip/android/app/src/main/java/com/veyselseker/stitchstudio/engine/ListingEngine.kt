package com.veyselseker.stitchstudio.engine

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ListingEngine {
    fun writeEtsy(p: PatternResult, file: File) {
        val (wi, hi) = p.sizeInches()
        val (wc, hc) = p.sizeCm()
        val title = "${p.title} Cross Stitch Pattern PDF | ${p.width}x${p.height} | ${p.colorCount} DMC | Instant Download".take(140)
        val tags = listOf(
            "cross stitch pattern", "pdf pattern", "counted cross stitch", "dmc pattern",
            "instant download", "embroidery pattern", "modern cross stitch", "digital pattern",
            "diy wall art", "hoop art", "aida 14", "needlepoint pdf", "handmade gift"
        ).joinToString(", ")
        file.writeText(
            """
            TITLE
            $title

            TAGS
            $tags

            DESCRIPTION
            ${p.title} — counted cross stitch pattern (digital PDF).

            WHAT YOU GET
            • Printable PDF chart with symbols
            • DMC colour key (${p.colorCount} colours)
            • Mockup previews
            • Instant download

            PATTERN DETAILS
            • Stitch count: ${p.width} × ${p.height}
            • Fabric: ${p.aida}-count Aida
            • Size: ${"%.1f".format(wi)}" × ${"%.1f".format(hi)}" (${"%.1f".format(wc)} × ${"%.1f".format(hc)} cm)
            • Total stitches: ${p.stitchCount}

            Digital item. Personal use. Designed with VEYSEL SEKER Pattern Studio.
            """.trimIndent()
        )
    }

    fun zipDir(src: File, dest: File) {
        ZipOutputStream(dest.outputStream()).use { zos ->
            src.walkTopDown().filter { it.isFile && it.extension.lowercase() != "zip" }.forEach { f ->
                val name = f.relativeTo(src).path.replace('\\', '/')
                zos.putNextEntry(ZipEntry(name))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }
}
