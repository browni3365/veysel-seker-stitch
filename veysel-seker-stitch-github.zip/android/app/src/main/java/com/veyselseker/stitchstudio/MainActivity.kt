package com.veyselseker.stitchstudio

import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.veyselseker.stitchstudio.databinding.ActivityMainBinding
import com.veyselseker.stitchstudio.engine.DmcEngine
import com.veyselseker.stitchstudio.engine.ListingEngine
import com.veyselseker.stitchstudio.engine.MockupEngine
import com.veyselseker.stitchstudio.engine.PatternEngine
import com.veyselseker.stitchstudio.engine.PdfEngine
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var imageUri: Uri? = null
    private var lastZip: File? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            imageUri = uri
            binding.preview.setImageURI(uri)
            log("Görsel seçildi.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnPick.setOnClickListener { picker.launch("image/*") }
        binding.btnGenerate.setOnClickListener { generate() }
        binding.btnShare.setOnClickListener { shareZip() }
    }

    private fun log(msg: String) {
        runOnUiThread {
            binding.log.append("\n$msg")
        }
    }

    private fun generate() {
        val uri = imageUri
        if (uri == null) {
            Toast.makeText(this, "Önce görsel seç.", Toast.LENGTH_SHORT).show()
            return
        }
        val title = binding.titleInput.text?.toString()?.ifBlank { "Pattern" } ?: "Pattern"
        val width = binding.widthInput.text?.toString()?.toIntOrNull() ?: 64
        val colors = binding.colorsInput.text?.toString()?.toIntOrNull() ?: 28
        val aida = binding.aidaInput.text?.toString()?.toIntOrNull() ?: 14
        binding.progress.visibility = View.VISIBLE
        binding.btnGenerate.isEnabled = false
        thread {
            try {
                val bmp = loadBitmap(uri) ?: throw IllegalStateException("Görsel okunamadı")
                log("DMC eşleştiriliyor…")
                val dmc = DmcEngine(this)
                val pattern = PatternEngine(dmc).generate(bmp, width.coerceIn(20, 160), colors.coerceIn(6, 80), aida, title)
                val slug = title.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "pattern" }
                val dir = File(getExternalFilesDir(null), slug).apply { mkdirs() }
                FileOutputStream(File(dir, "pattern_preview.png")).use {
                    pattern.preview.compress(android.graphics.Bitmap.CompressFormat.PNG, 95, it)
                }
                log("PDF yazılıyor… ${pattern.width}x${pattern.height} / ${pattern.colorCount} renk")
                PdfEngine().render(pattern, File(dir, "${slug}_pattern.pdf"))
                log("Mockup…")
                MockupEngine().renderAll(pattern, File(dir, "mockups"))
                ListingEngine().writeEtsy(pattern, File(dir, "etsy_listing.txt"))
                val zip = File(getExternalFilesDir(null), "${slug}_SHOP.zip")
                ListingEngine().zipDir(dir, zip)
                lastZip = zip
                runOnUiThread {
                    binding.preview.setImageBitmap(pattern.preview)
                    binding.btnShare.visibility = View.VISIBLE
                    binding.progress.visibility = View.GONE
                    binding.btnGenerate.isEnabled = true
                }
                log("Bitti.\nKlasör: ${dir.absolutePath}\nZIP: ${zip.name} (${zip.length() / 1024} KB)")
            } catch (e: Exception) {
                log("HATA: ${e.message}")
                runOnUiThread {
                    binding.progress.visibility = View.GONE
                    binding.btnGenerate.isEnabled = true
                    Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun loadBitmap(uri: Uri) = try {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, _, _ ->
                decoder.isMutableRequired = true
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(contentResolver, uri)
        }
    } catch (_: Exception) {
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    }

    private fun shareZip() {
        val zip = lastZip ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.files", zip)
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(android.content.Intent.createChooser(intent, "ZIP paylaş"))
    }
}
