package com.veyselseker.stitchstudio.engine

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.roundToInt

data class PatternResult(
    val width: Int,
    val height: Int,
    val grid: Array<Array<String>>,
    val palette: List<DmcColor>,
    val counts: Map<String, Int>,
    val symbols: Map<String, String>,
    val preview: Bitmap,
    val title: String,
    val aida: Int
) {
    val colorCount get() = palette.size
    val stitchCount get() = width * height
    fun sizeInches() = width.toFloat() / aida to height.toFloat() / aida
    fun sizeCm(): Pair<Float, Float> {
        val (w, h) = sizeInches()
        return w * 2.54f to h * 2.54f
    }
}

class PatternEngine(private val dmc: DmcEngine) {
    fun generate(src: Bitmap, width: Int, maxColors: Int, aida: Int, title: String): PatternResult {
        val ratio = src.height.toFloat() / src.width.toFloat()
        val height = max(8, (width * ratio).roundToInt())
        val small = Bitmap.createScaledBitmap(src, width, height, true)
        val used = LinkedHashMap<String, DmcColor>()
        val counts = HashMap<String, Int>()
        val grid = Array(height) { Array(width) { "310" } }
        val preview = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val p = small.getPixel(x, y)
                val c = dmc.nearest(Color.red(p), Color.green(p), Color.blue(p))
                grid[y][x] = c.code
                used[c.code] = c
                counts[c.code] = (counts[c.code] ?: 0) + 1
                preview.setPixel(x, y, c.colorInt)
            }
        }
        var palette = used.values.sortedByDescending { counts[it.code] ?: 0 }
        var finalGrid = grid
        var finalCounts = counts
        var finalUsed = used
        if (palette.size > maxColors) {
            val keep = palette.take(maxColors).map { it.code }.toSet()
            val remap = HashMap<String, String>()
            for (c in palette) {
                if (c.code in keep) {
                    remap[c.code] = c.code
                    continue
                }
                var best: String? = null
                var bestD = Long.MAX_VALUE
                for (k in keep) {
                    val t = finalUsed[k]!!
                    val d = dist(c, t)
                    if (d < bestD) {
                        bestD = d
                        best = k
                    }
                }
                remap[c.code] = best ?: keep.first()
            }
            val ng = Array(height) { Array(width) { "310" } }
            val nc = HashMap<String, Int>()
            for (y in 0 until height) {
                for (x in 0 until width) {
                    val code = remap[finalGrid[y][x]] ?: finalGrid[y][x]
                    ng[y][x] = code
                    nc[code] = (nc[code] ?: 0) + 1
                    preview.setPixel(x, y, finalUsed[code]!!.colorInt)
                }
            }
            finalGrid = ng
            finalCounts = nc
            finalUsed = LinkedHashMap(finalUsed.filterKeys { it in keep })
            palette = finalUsed.values.sortedByDescending { finalCounts[it.code] ?: 0 }
        }
        val big = Bitmap.createScaledBitmap(preview, width * 8, height * 8, false)
        return PatternResult(
            width, height, finalGrid, palette, finalCounts,
            dmc.symbolsFor(palette.map { it.code }), big, title, aida
        )
    }

    private fun dist(a: DmcColor, b: DmcColor): Long {
        val dr = (a.r - b.r).toLong()
        val dg = (a.g - b.g).toLong()
        val db = (a.b - b.b).toLong()
        return dr * dr + dg * dg + db * db
    }
}
