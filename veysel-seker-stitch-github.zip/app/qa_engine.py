"""Lightweight QA checks on a finished pattern."""

from __future__ import annotations

from dataclasses import dataclass, field

from .pattern_engine import PatternResult


@dataclass
class QAReport:
    ok: bool
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


class QAEngine:
    def check(self, pattern: PatternResult) -> QAReport:
        r = QAReport(ok=True)
        if pattern.width < 20 or pattern.height < 20:
            r.errors.append("Pattern is smaller than 20×20 — too tiny for a listing.")
        if pattern.color_count < 4:
            r.warnings.append("Very few colours; photo may look posterized.")
        if pattern.color_count > 80:
            r.warnings.append("More than 80 colours — expensive / slow to stitch.")
        rare = [c for c, n in pattern.counts.items() if n < 4]
        if rare:
            r.warnings.append(f"{len(rare)} colours used fewer than 4 times (consider merging).")
        singles = sum(1 for n in pattern.counts.values() if n == 1)
        if singles > pattern.color_count * 0.15:
            r.warnings.append("Many singleton stitches — noisy source image.")
        w_in, h_in = pattern.size_inches()
        if w_in > 20 or h_in > 20:
            r.warnings.append("Finished size over 20 inches on chosen Aida.")
        r.notes.append(f"{pattern.stitch_count} stitches, {pattern.color_count} DMC, Aida {pattern.aida}")
        r.ok = not r.errors
        return r

    def as_text(self, report: QAReport) -> str:
        lines = ["QA REPORT", f"Status: {'PASS' if report.ok else 'FAIL'}"]
        for e in report.errors:
            lines.append(f"ERROR: {e}")
        for w in report.warnings:
            lines.append(f"WARN: {w}")
        for n in report.notes:
            lines.append(f"NOTE: {n}")
        return "\n".join(lines) + "\n"
