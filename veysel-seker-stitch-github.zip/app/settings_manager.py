"""Local JSON settings — no license, no telemetry."""

from __future__ import annotations

import json
from pathlib import Path

DEFAULTS = {
    "default_width": 80,
    "default_max_colors": 36,
    "default_aida": 14,
    "output_root": "output",
    "language": "tr",
}


class SettingsManager:
    def __init__(self, path: str | Path | None = None) -> None:
        root = Path(__file__).resolve().parent.parent
        self.path = Path(path) if path else root / "data" / "settings.json"
        self.data = dict(DEFAULTS)
        self.load()

    def load(self) -> None:
        if self.path.exists():
            try:
                self.data.update(json.loads(self.path.read_text(encoding="utf-8")))
            except json.JSONDecodeError:
                pass

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")

    def get(self, key: str, default=None):
        return self.data.get(key, default)

    def set(self, key: str, value) -> None:
        self.data[key] = value
        self.save()
