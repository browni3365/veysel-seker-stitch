"""VEYSEL SEKER — local Etsy cross-stitch pattern studio."""

__version__ = "3.1.0"
