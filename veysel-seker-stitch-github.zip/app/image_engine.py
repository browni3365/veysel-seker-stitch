"""Image load / resize / crop helpers."""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageEnhance, ImageFilter, ImageOps


class ImageEngine:
    def load(self, path: str | Path) -> Image.Image:
        img = Image.open(path)
        img = ImageOps.exif_transpose(img)
        return img.convert("RGB")

    def enhance(
        self,
        img: Image.Image,
        contrast: float = 1.08,
        color: float = 1.12,
        sharpness: float = 1.15,
    ) -> Image.Image:
        img = ImageEnhance.Contrast(img).enhance(contrast)
        img = ImageEnhance.Color(img).enhance(color)
        img = ImageEnhance.Sharpness(img).enhance(sharpness)
        return img

    def fit_square(self, img: Image.Image, size: int) -> Image.Image:
        return ImageOps.fit(img, (size, size), Image.Resampling.LANCZOS)

    def posterize(self, img: Image.Image, bits: int = 5) -> Image.Image:
        return ImageOps.posterize(img.convert("RGB"), bits)

    def soft_blur(self, img: Image.Image, r: float = 0.6) -> Image.Image:
        return img.filter(ImageFilter.GaussianBlur(r))
