"""ZIP packaging of a finished listing."""

from __future__ import annotations

import zipfile
from pathlib import Path


class PackageEngine:
    def zip_dir(self, src: Path, dest: Path) -> Path:
        dest.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in sorted(src.rglob("*")):
                if p.is_file() and p.suffix.lower() != ".zip":
                    zf.write(p, p.relative_to(src))
        return dest

    def buyer_zip(self, listing_dir: Path, dest: Path) -> Path:
        """PDF + readme only — what the buyer receives."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in listing_dir.rglob("*"):
                if p.suffix.lower() in {".pdf", ".txt"} and "etsy" not in p.name.lower():
                    zf.write(p, p.name)
        return dest
