"""End-to-end generate: pattern → PDF → mockups → Etsy → ZIP → QA."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .dmc_engine import DMCEngine
from .etsy_engine import EtsyEngine
from .history_manager import HistoryManager
from .image_engine import ImageEngine
from .mockup_engine import MockupEngine
from .package_engine import PackageEngine
from .pattern_engine import PatternEngine, PatternResult
from .pdf_engine import PDFEngine
from .qa_engine import QAEngine
from .store_manager import StoreManager


@dataclass
class PipelineResult:
    folder: Path
    pattern: PatternResult
    files: list[Path]
    qa_text: str


class Pipeline:
    def __init__(self, output_root: str | Path) -> None:
        self.dmc = DMCEngine()
        self.images = ImageEngine()
        self.patterns = PatternEngine(self.dmc)
        self.pdf = PDFEngine()
        self.mockups = MockupEngine()
        self.etsy = EtsyEngine()
        self.pack = PackageEngine()
        self.qa = QAEngine()
        self.store = StoreManager(output_root)
        self.history = HistoryManager()

    def run(
        self,
        image_path: str | Path,
        title: str,
        width: int = 80,
        max_colors: int = 36,
        aida: int = 14,
    ) -> PipelineResult:
        image_path = Path(image_path)
        img = self.images.enhance(self.images.load(image_path))
        pattern = self.patterns.generate(
            img,
            width=width,
            max_colors=max_colors,
            aida=aida,
            source_name=title,
        )
        folder = self.store.listing_dir(title)
        files: list[Path] = []

        preview = folder / "pattern_preview.png"
        pattern.preview.save(preview)
        files.append(preview)

        pdf = self.pdf.render(pattern, folder / f"{folder.name}_pattern.pdf", title=title)
        files.append(pdf)

        mocks = self.mockups.render_all(pattern, folder / "mockups", title=title)
        files.extend(mocks)

        etsy = self.etsy.write(pattern, title, folder / "etsy_listing.txt")
        files.append(etsy)

        qa = self.qa.check(pattern)
        qa_path = folder / "qa_report.txt"
        qa_path.write_text(self.qa.as_text(qa), encoding="utf-8")
        files.append(qa_path)

        shop_zip = self.pack.zip_dir(folder, folder.parent / f"{folder.name}_SHOP.zip")
        buyer_zip = self.pack.buyer_zip(folder, folder.parent / f"{folder.name}_BUYER.zip")
        files.extend([shop_zip, buyer_zip])

        self.history.add(
            {
                "title": title,
                "folder": str(folder),
                "width": pattern.width,
                "height": pattern.height,
                "colors": pattern.color_count,
            }
        )
        return PipelineResult(folder=folder, pattern=pattern, files=files, qa_text=self.qa.as_text(qa))
