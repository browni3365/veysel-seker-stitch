"""Quantize an image onto a DMC stitch grid."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

import numpy as np
from PIL import Image

from .dmc_engine import DMCColor, DMCEngine


@dataclass
class PatternResult:
    width: int
    height: int
    grid: list[list[str]]  # DMC codes
    palette: list[DMCColor]
    counts: dict[str, int]
    symbols: dict[str, str]
    preview: Image.Image
    source_name: str = "pattern"
    aida: int = 14
    extra: dict = field(default_factory=dict)

    @property
    def color_count(self) -> int:
        return len(self.palette)

    @property
    def stitch_count(self) -> int:
        return self.width * self.height

    def size_inches(self) -> tuple[float, float]:
        return self.width / self.aida, self.height / self.aida

    def size_cm(self) -> tuple[float, float]:
        w, h = self.size_inches()
        return w * 2.54, h * 2.54


class PatternEngine:
    def __init__(self, dmc: DMCEngine | None = None) -> None:
        self.dmc = dmc or DMCEngine()

    def generate(
        self,
        image: Image.Image,
        width: int = 80,
        height: int | None = None,
        max_colors: int = 40,
        aida: int = 14,
        source_name: str = "pattern",
    ) -> PatternResult:
        img = image.convert("RGB")
        if height is None:
            ratio = img.height / img.width
            height = max(8, int(round(width * ratio)))
        small = img.resize((width, height), Image.Resampling.BOX)

        # k-means-ish via adaptive palette then map to DMC
        q = small.quantize(colors=max(8, min(max_colors, 128)), method=Image.Quantize.MEDIANCUT)
        q = q.convert("RGB")
        arr = np.asarray(q, dtype=np.uint8)

        grid: list[list[str]] = []
        used: dict[str, DMCColor] = {}
        counts: Counter[str] = Counter()
        preview = np.zeros_like(arr)

        for y in range(height):
            row: list[str] = []
            for x in range(width):
                r, g, b = (int(arr[y, x, 0]), int(arr[y, x, 1]), int(arr[y, x, 2]))
                c = self.dmc.nearest((r, g, b))
                row.append(c.code)
                used[c.code] = c
                counts[c.code] += 1
                preview[y, x] = c.rgb
            grid.append(row)

        # reduce if still too many colors
        if len(used) > max_colors:
            keep = {code for code, _ in counts.most_common(max_colors)}
            remap: dict[str, str] = {}
            for code in list(used):
                if code in keep:
                    remap[code] = code
                    continue
                src = used[code]
                best = None
                best_d = 1e18
                for k in keep:
                    t = used[k]
                    d = (src.r - t.r) ** 2 + (src.g - t.g) ** 2 + (src.b - t.b) ** 2
                    if d < best_d:
                        best_d = d
                        best = k
                remap[code] = best or next(iter(keep))
            new_grid = []
            new_counts: Counter[str] = Counter()
            for y, row in enumerate(grid):
                nr = []
                for x, code in enumerate(row):
                    nc = remap[code]
                    nr.append(nc)
                    new_counts[nc] += 1
                    preview[y, x] = used[nc].rgb
                new_grid.append(nr)
            grid = new_grid
            counts = new_counts
            used = {c: used[c] for c in keep}

        palette = sorted(used.values(), key=lambda c: -counts[c.code])
        symbols = self.dmc.symbols_for([c.code for c in palette])
        prev_img = Image.fromarray(preview, "RGB").resize(
            (width * 8, height * 8), Image.Resampling.NEAREST
        )
        return PatternResult(
            width=width,
            height=height,
            grid=grid,
            palette=palette,
            counts=dict(counts),
            symbols=symbols,
            preview=prev_img,
            source_name=source_name,
            aida=aida,
        )
