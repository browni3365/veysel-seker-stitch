"""Organize output folders per listing slug."""

from __future__ import annotations

import re
from pathlib import Path


def slugify(name: str) -> str:
    s = name.strip().lower()
    s = re.sub(r"[^a-z0-9ğüşöçıİ]+", "-", s, flags=re.I)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "pattern"


class StoreManager:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def listing_dir(self, title: str) -> Path:
        d = self.root / slugify(title)
        (d / "mockups").mkdir(parents=True, exist_ok=True)
        return d
