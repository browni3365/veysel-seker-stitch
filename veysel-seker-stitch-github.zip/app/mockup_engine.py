"""V3 mockups: hoop, square, rectangle, close-up, lifestyle, Etsy hero."""

from __future__ import annotations

import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

from .pattern_engine import PatternResult


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for p in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    ):
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def _aida_texture(w: int, h: int, seed: int = 3) -> Image.Image:
    rng = random.Random(seed)
    img = Image.new("RGB", (w, h), (246, 239, 226))
    px = img.load()
    step = max(4, w // 80)
    for y in range(h):
        for x in range(w):
            n = rng.randint(-8, 8)
            base = 246 + n
            if x % step == 0 or y % step == 0:
                px[x, y] = (max(180, base - 28), max(170, base - 34), max(150, base - 42))
            else:
                px[x, y] = (min(255, base), min(255, base - 6), min(255, base - 16))
    return img


def _wood(w: int, h: int, seed: int = 7) -> Image.Image:
    rng = random.Random(seed)
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        for x in range(w):
            wave = math.sin(x / 28 + math.sin(y / 40) * 2) * 18
            v = 118 + wave + rng.randint(-6, 6)
            px[x, y] = (int(v + 40), int(v + 12), int(v - 20))
    return img.filter(ImageFilter.GaussianBlur(0.4))


def _xstitch(pattern: PatternResult, scale: int = 10) -> Image.Image:
    w, h = pattern.width * scale, pattern.height * scale
    cloth = _aida_texture(w, h)
    draw = ImageDraw.Draw(cloth)
    pal = {c.code: c.rgb for c in pattern.palette}
    for y, row in enumerate(pattern.grid):
        for x, code in enumerate(row):
            rgb = pal[code]
            x0, y0 = x * scale, y * scale
            x1, y1 = x0 + scale - 1, y0 + scale - 1
            # two legs of the X
            draw.line((x0 + 1, y0 + 1, x1 - 1, y1 - 1), fill=rgb, width=max(2, scale // 4))
            draw.line((x0 + 1, y1 - 1, x1 - 1, y0 + 1), fill=rgb, width=max(2, scale // 4))
    return cloth


class MockupEngine:
    def render_all(self, pattern: PatternResult, out_dir: str | Path, title: str = "") -> list[Path]:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        title = title or pattern.source_name.replace("_", " ").title()
        stitch = _xstitch(pattern, scale=8)
        paths: list[Path] = []
        makers = [
            ("01_round_hoop", self.round_hoop),
            ("02_square_frame", self.square_frame),
            ("03_rectangle_frame", self.rectangle_frame),
            ("04_closeup", self.closeup),
            ("05_lifestyle", self.lifestyle),
            ("06_etsy_hero", self.etsy_hero),
        ]
        for name, fn in makers:
            img = fn(stitch, pattern, title)
            p = out_dir / f"{name}.png"
            img.save(p, "PNG")
            paths.append(p)
        return paths

    def round_hoop(self, stitch: Image.Image, pattern: PatternResult, title: str) -> Image.Image:
        canvas = Image.new("RGB", (1400, 1400), (236, 228, 214))
        wood = _wood(1400, 1400)
        # circular mask of stitch
        side = 980
        st = ImageOps.fit(stitch, (side, side), Image.Resampling.NEAREST)
        mask = Image.new("L", (side, side), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, side - 1, side - 1), fill=255)
        hoop = Image.new("RGB", (side + 90, side + 90), (0, 0, 0))
        hoop.paste(wood.resize((side + 90, side + 90)), (0, 0))
        hoop.paste(st, (45, 45), mask)
        # inner ring
        d = ImageDraw.Draw(hoop)
        d.ellipse((20, 20, side + 70, side + 70), outline=(90, 50, 20), width=18)
        d.ellipse((38, 38, side + 52, side + 52), outline=(160, 110, 55), width=8)
        canvas.paste(hoop, ((1400 - hoop.width) // 2, 80))
        draw = ImageDraw.Draw(canvas)
        draw.text((700, 1280), title, font=_font(36), fill=(40, 32, 24), anchor="mm")
        return canvas

    def square_frame(self, stitch: Image.Image, pattern: PatternResult, title: str) -> Image.Image:
        st = ImageOps.contain(stitch, (900, 900), Image.Resampling.NEAREST)
        frame = 70
        w, h = st.width + frame * 2, st.height + frame * 2
        wood = _wood(w + 200, h + 280)
        canvas = wood.resize((w + 200, h + 280))
        canvas.paste(st, (100 + frame, 80 + frame))
        d = ImageDraw.Draw(canvas)
        x0, y0 = 100, 80
        d.rectangle((x0, y0, x0 + w, y0 + h), outline=(70, 40, 18), width=frame)
        d.rectangle((x0 + 16, y0 + 16, x0 + w - 16, y0 + h - 16), outline=(190, 150, 80), width=6)
        d.text((canvas.width // 2, canvas.height - 70), title, font=_font(32), fill=(255, 240, 210), anchor="mm")
        return canvas

    def rectangle_frame(self, stitch: Image.Image, pattern: PatternResult, title: str) -> Image.Image:
        target = (1100, 800)
        st = ImageOps.fit(stitch, target, Image.Resampling.NEAREST)
        canvas = Image.new("RGB", (1400, 1100), (32, 36, 44))
        wood = _wood(1400, 1100, seed=11)
        canvas.paste(wood, (0, 0))
        fx, fy = 150, 110
        canvas.paste(st, (fx, fy))
        d = ImageDraw.Draw(canvas)
        d.rectangle((fx - 40, fy - 40, fx + target[0] + 40, fy + target[1] + 40), outline=(55, 32, 16), width=40)
        return canvas

    def closeup(self, stitch: Image.Image, pattern: PatternResult, title: str) -> Image.Image:
        crop = stitch.crop((0, 0, min(stitch.width, 400), min(stitch.height, 400)))
        crop = crop.resize((1200, 1200), Image.Resampling.NEAREST)
        return crop

    def lifestyle(self, stitch: Image.Image, pattern: PatternResult, title: str) -> Image.Image:
        canvas = Image.new("RGB", (1600, 1200), (214, 205, 190))
        # table
        wood = _wood(1600, 1200, seed=21)
        canvas.paste(Image.blend(wood, Image.new("RGB", wood.size, (214, 205, 190)), 0.35))
        hoop = self.round_hoop(stitch, pattern, "")
        hoop = hoop.resize((780, 780), Image.Resampling.LANCZOS)
        canvas.paste(hoop, (80, 180))
        d = ImageDraw.Draw(canvas)
        # scissors / thread blobs
        d.ellipse((980, 260, 1120, 400), fill=(180, 40, 70))
        d.ellipse((1140, 320, 1240, 420), fill=(40, 90, 160))
        d.ellipse((1060, 440, 1180, 560), fill=(220, 180, 60))
        d.rounded_rectangle((980, 700, 1480, 980), 16, fill=(248, 244, 236))
        d.text((1230, 780), "DMC floss + 14ct Aida", font=_font(28), fill=(40, 32, 24), anchor="mm")
        d.text((1230, 840), title[:36], font=_font(22), fill=(90, 70, 40), anchor="mm")
        return canvas

    def etsy_hero(self, stitch: Image.Image, pattern: PatternResult, title: str) -> Image.Image:
        # 3000x2250-ish listing hero, scaled 2000x1500
        w, h = 2000, 1500
        canvas = Image.new("RGB", (w, h), (24, 24, 38))
        d = ImageDraw.Draw(canvas)
        d.rectangle((0, 0, w, 18), fill=(201, 162, 39))
        d.rectangle((0, h - 18, w, h), fill=(201, 162, 39))
        hoop = self.round_hoop(stitch, pattern, "")
        hoop = hoop.resize((980, 980), Image.Resampling.LANCZOS)
        canvas.paste(hoop, (80, 240))
        d.text((1480, 280), "CROSS STITCH", font=_font(36), fill=(201, 162, 39), anchor="mm")
        # wrap title
        d.text((1480, 400), title[:28], font=_font(54), fill=(255, 255, 255), anchor="mm")
        w_in, h_in = pattern.size_inches()
        lines = [
            f"{pattern.width} × {pattern.height} stitches",
            f"{pattern.color_count} DMC colours",
            f"{pattern.aida}-count  ·  {w_in:.1f}\" × {h_in:.1f}\"",
            "Instant PDF download",
            "Full symbol chart + key",
        ]
        yy = 560
        for line in lines:
            d.text((1480, yy), line, font=_font(32), fill=(230, 224, 210), anchor="mm")
            yy += 70
        d.rounded_rectangle((1240, 1080, 1720, 1180), 12, fill=(201, 162, 39))
        d.text((1480, 1130), "DIGITAL PATTERN", font=_font(28), fill=(24, 24, 38), anchor="mm")
        return canvas
