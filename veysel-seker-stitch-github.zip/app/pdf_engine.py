"""V3 PDF: cover, paginated symbol chart, DMC key, ReadMe."""

from __future__ import annotations

import tempfile
from pathlib import Path

from PIL import Image as PILImage
from reportlab.lib.colors import Color, HexColor, black, white
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

from .pattern_engine import PatternResult

PAGE_W, PAGE_H = A4


def _register_fonts() -> str:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ]
    for p in candidates:
        if Path(p).exists():
            pdfmetrics.registerFont(TTFont("AppSans", p))
            bold = p.replace("Regular", "Bold").replace("DejaVuSans.ttf", "DejaVuSans-Bold.ttf")
            if Path(bold).exists():
                pdfmetrics.registerFont(TTFont("AppSans-Bold", bold))
            else:
                pdfmetrics.registerFont(TTFont("AppSans-Bold", p))
            return "AppSans"
    return "Helvetica"


FONT = _register_fonts()
FONTB = "AppSans-Bold" if FONT == "AppSans" else "Helvetica-Bold"


class PDFEngine:
    def __init__(self) -> None:
        self.overlap_rows = 3
        self.cells_x = 35
        self.cells_y = 42

    def render(self, pattern: PatternResult, out_path: str | Path, title: str = "") -> Path:
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        title = title or pattern.source_name.replace("_", " ").title()
        c = canvas.Canvas(str(out_path), pagesize=A4)
        self._cover(c, pattern, title)
        self._chart_pages(c, pattern, title)
        self._key_pages(c, pattern, title)
        self._readme(c, pattern, title)
        c.save()
        return out_path

    def _header(self, c: canvas.Canvas, title: str, subtitle: str) -> None:
        c.setFillColor(HexColor("#1B1B2F"))
        c.rect(0, PAGE_H - 18 * mm, PAGE_W, 18 * mm, fill=1, stroke=0)
        c.setFillColor(HexColor("#C9A227"))
        c.rect(0, PAGE_H - 18.8 * mm, PAGE_W, 1.2 * mm, fill=1, stroke=0)
        c.setFillColor(white)
        c.setFont(FONTB, 11)
        c.drawString(14 * mm, PAGE_H - 11 * mm, "VEYSEL ŞEKER  ·  Cross Stitch Pattern")
        c.setFont(FONT, 8)
        c.drawRightString(PAGE_W - 14 * mm, PAGE_H - 11 * mm, subtitle)
        c.setFillColor(HexColor("#C9A227"))
        c.setFont(FONT, 8)
        c.drawString(14 * mm, PAGE_H - 16 * mm, title)

    def _footer(self, c: canvas.Canvas, page: int, total_hint: str = "") -> None:
        c.setFillColor(HexColor("#1B1B2F"))
        c.rect(0, 0, PAGE_W, 10 * mm, fill=1, stroke=0)
        c.setFillColor(HexColor("#C9A227"))
        c.rect(0, 10 * mm, PAGE_W, 0.8 * mm, fill=1, stroke=0)
        c.setFillColor(white)
        c.setFont(FONT, 8)
        c.drawString(14 * mm, 4 * mm, "Personal use · Digital download · Made locally")
        c.drawRightString(PAGE_W - 14 * mm, 4 * mm, f"Page {page}  {total_hint}")

    def _cover(self, c: canvas.Canvas, p: PatternResult, title: str) -> None:
        # full-bleed navy
        c.setFillColor(HexColor("#141422"))
        c.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
        # gold frame
        c.setStrokeColor(HexColor("#C9A227"))
        c.setLineWidth(2.2)
        c.rect(10 * mm, 10 * mm, PAGE_W - 20 * mm, PAGE_H - 20 * mm, fill=0, stroke=1)
        c.setLineWidth(0.6)
        c.rect(12 * mm, 12 * mm, PAGE_W - 24 * mm, PAGE_H - 24 * mm, fill=0, stroke=1)

        c.setFillColor(HexColor("#C9A227"))
        c.setFont(FONT, 9)
        c.drawCentredString(PAGE_W / 2, PAGE_H - 28 * mm, "DIGITAL CROSS STITCH PATTERN")
        c.setFillColor(white)
        c.setFont(FONTB, 26)
        # wrap title
        c.drawCentredString(PAGE_W / 2, PAGE_H - 42 * mm, title[:42])

        # preview
        preview = p.preview.copy()
        max_w, max_h = 120 * mm, 120 * mm
        iw, ih = preview.size
        scale = min(max_w / iw, max_h / ih)
        dw, dh = iw * scale, ih * scale
        x = (PAGE_W - dw) / 2
        y = PAGE_H / 2 - dh / 2 + 8 * mm
        c.setFillColor(HexColor("#1F1F35"))
        c.roundRect(x - 4 * mm, y - 4 * mm, dw + 8 * mm, dh + 8 * mm, 4, fill=1, stroke=0)
        tmp = Path(tempfile.gettempdir()) / "veysel_cover_preview.png"
        preview.save(tmp)
        c.drawImage(str(tmp), x, y, dw, dh, preserveAspectRatio=True, mask="auto")

        w_in, h_in = p.size_inches()
        w_cm, h_cm = p.size_cm()
        stats = [
            f"{p.width} × {p.height} stitches",
            f"{p.color_count} DMC colours",
            f"{p.aida}-count Aida  ·  {w_in:.1f}\" × {h_in:.1f}\"  ({w_cm:.1f} × {h_cm:.1f} cm)",
            f"{p.stitch_count:,} total stitches",
        ]
        c.setFillColor(HexColor("#E8E0C8"))
        c.setFont(FONT, 11)
        yy = 48 * mm
        for s in stats:
            c.drawCentredString(PAGE_W / 2, yy, s)
            yy -= 6 * mm

        c.setFillColor(HexColor("#C9A227"))
        c.setFont(FONTB, 10)
        c.drawCentredString(PAGE_W / 2, 22 * mm, "VEYSEL ŞEKER")
        c.setFont(FONT, 8)
        c.setFillColor(HexColor("#A0A0B8"))
        c.drawCentredString(PAGE_W / 2, 16 * mm, "Pattern · Colour Key · Mockups · Etsy Ready")
        c.showPage()

    def _chart_pages(self, c: canvas.Canvas, p: PatternResult, title: str) -> None:
        cx, cy = self.cells_x, self.cells_y
        overlap = self.overlap_rows
        step_y = cy - overlap
        cols = (p.width + cx - 1) // cx
        rows = 1 if p.height <= cy else 1 + (p.height - cy + step_y - 1) // step_y
        page_i = 2
        left = 12 * mm
        top = PAGE_H - 28 * mm
        usable_w = PAGE_W - 24 * mm
        usable_h = PAGE_H - 44 * mm
        cell = min(usable_w / cx, usable_h / cy)

        palmap = {k.code: k for k in p.palette}
        for ry in range(rows):
            y0 = 0 if ry == 0 else ry * step_y
            y1 = min(p.height, y0 + cy)
            for rx in range(cols):
                x0 = rx * cx
                x1 = min(p.width, x0 + cx)
                self._header(c, title, f"Chart  {rx+1},{ry+1}  ·  stitches {x0+1}-{x1} × {y0+1}-{y1}")
                # draw cells
                for yy in range(y0, y1):
                    for xx in range(x0, x1):
                        code = p.grid[yy][xx]
                        col = palmap.get(code)
                        hexv = col.hex if col else "#CCCCCC"
                        px = left + (xx - x0) * cell
                        py = top - (yy - y0 + 1) * cell
                        c.setFillColor(HexColor(hexv))
                        c.rect(px, py, cell, cell, fill=1, stroke=0)
                        # symbol
                        lum = (col.r * 299 + col.g * 587 + col.b * 114) / 1000 if col else 128
                        c.setFillColor(white if lum < 140 else black)
                        c.setFont(FONTB, max(4, min(7, cell * 1.6)))
                        c.drawCentredString(px + cell / 2, py + cell * 0.28, p.symbols.get(code, "?"))
                # grid lines
                c.setStrokeColor(HexColor("#333333"))
                for i in range(x1 - x0 + 1):
                    c.setLineWidth(1.1 if i % 10 == 0 else 0.25)
                    xx = left + i * cell
                    c.line(xx, top, xx, top - (y1 - y0) * cell)
                for j in range(y1 - y0 + 1):
                    c.setLineWidth(1.1 if j % 10 == 0 else 0.25)
                    yy = top - j * cell
                    c.line(left, yy, left + (x1 - x0) * cell, yy)
                # numbers
                c.setFillColor(HexColor("#444444"))
                c.setFont(FONT, 6)
                for i in range(x0, x1):
                    if (i + 1) % 10 == 0 or i == x0:
                        c.drawCentredString(left + (i - x0 + 0.5) * cell, top + 1.5 * mm, str(i + 1))
                for j in range(y0, y1):
                    if (j + 1) % 10 == 0 or j == y0:
                        c.drawRightString(left - 1.2 * mm, top - (j - y0 + 0.7) * cell, str(j + 1))
                if ry > 0:
                    c.setFillColor(Color(0.8, 0.15, 0.15, alpha=0.12))
                    c.rect(left, top - overlap * cell, (x1 - x0) * cell, overlap * cell, fill=1, stroke=0)
                    c.setFillColor(HexColor("#AA2222"))
                    c.setFont(FONT, 6)
                    c.drawString(left + 1 * mm, top - 2.8 * mm, "overlap")
                self._footer(c, page_i)
                c.showPage()
                page_i += 1

    def _key_pages(self, c: canvas.Canvas, p: PatternResult, title: str) -> None:
        page = c.getPageNumber()
        self._header(c, title, "DMC Colour Key")
        # 5 columns
        cols = 5
        left = 12 * mm
        top = PAGE_H - 30 * mm
        col_w = (PAGE_W - 24 * mm) / cols
        row_h = 8.2 * mm
        max_rows = int((PAGE_H - 48 * mm) / row_h)
        per_page = max_rows * cols
        items = p.palette
        idx = 0
        while idx < len(items):
            if idx > 0:
                self._header(c, title, "DMC Colour Key (cont.)")
            chunk = items[idx : idx + per_page]
            for n, col in enumerate(chunk):
                ci = n % cols
                ri = n // cols
                x = left + ci * col_w
                y = top - (ri + 1) * row_h
                c.setFillColor(HexColor(col.hex))
                c.rect(x, y + 1.5 * mm, 6 * mm, 5.2 * mm, fill=1, stroke=1)
                c.setFillColor(black)
                c.setFont(FONTB, 7)
                c.drawString(x + 7 * mm, y + 4.4 * mm, f"{p.symbols[col.code]}  {col.code}")
                c.setFont(FONT, 5.5)
                c.setFillColor(HexColor("#444444"))
                name = col.name[:18]
                c.drawString(x + 7 * mm, y + 1.8 * mm, f"{name}  ·  {p.counts.get(col.code, 0)}")
            self._footer(c, c.getPageNumber())
            c.showPage()
            idx += per_page

    def _readme(self, c: canvas.Canvas, p: PatternResult, title: str) -> None:
        self._header(c, title, "How to stitch")
        w_in, h_in = p.size_inches()
        w_cm, h_cm = p.size_cm()
        body = [
            f"Design: {title}",
            f"Grid: {p.width} × {p.height} stitches on {p.aida}-count Aida.",
            f"Finished size: {w_in:.2f}\" × {h_in:.2f}\"  ({w_cm:.1f} × {h_cm:.1f} cm).",
            f"Palette: {p.color_count} DMC stranded cotton colours. Use 2 strands on 14-count.",
            "",
            "Each square is one full cross stitch. Match the symbol in the square",
            "to the DMC key. Bold lines mark every 10 stitches to help you count.",
            "Chart pages overlap by 3 rows so you never lose your place.",
            "",
            "Start from the centre of the fabric. Fold the Aida in quarters,",
            "crease lightly, and begin at the matching centre stitch of the chart.",
            "",
            "Backstitch is not required unless noted. Wash finished work gently",
            "in lukewarm water, roll in a towel, and iron face-down on a towel.",
            "",
            "This file is a digital pattern for personal use. You may stitch it",
            "as a gift. Please do not resell the PDF or the digital files.",
            "",
            "Teşekkürler — Veysel Şeker",
        ]
        c.setFillColor(HexColor("#222222"))
        y = PAGE_H - 32 * mm
        for line in body:
            c.setFont(FONTB if line.startswith("Design") else FONT, 10)
            c.drawString(18 * mm, y, line)
            y -= 6.2 * mm
        self._footer(c, c.getPageNumber())
        c.showPage()
