"""DMC floss matching — 170+ official-ish hex values."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

DATA = Path(__file__).resolve().parent.parent / "data" / "dmc_colors.json"


@dataclass(frozen=True)
class DMCColor:
    code: str
    name: str
    hex: str
    rgb: tuple[int, int, int]

    @property
    def r(self) -> int:
        return self.rgb[0]

    @property
    def g(self) -> int:
        return self.rgb[1]

    @property
    def b(self) -> int:
        return self.rgb[2]


def _hex_to_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


class DMCEngine:
    def __init__(self, palette_path: Path | None = None) -> None:
        path = palette_path or DATA
        raw = json.loads(path.read_text(encoding="utf-8"))
        self.colors: list[DMCColor] = [
            DMCColor(c["code"], c["name"], c["hex"], _hex_to_rgb(c["hex"]))
            for c in raw
        ]
        self._by_code = {c.code: c for c in self.colors}

    def __len__(self) -> int:
        return len(self.colors)

    def get(self, code: str) -> DMCColor | None:
        return self._by_code.get(str(code))

    def nearest(self, rgb: tuple[int, int, int]) -> DMCColor:
        r, g, b = rgb
        best = self.colors[0]
        best_d = 1e18
        for c in self.colors:
            dr, dg, db = r - c.r, g - c.g, b - c.b
            d = dr * dr + dg * dg + db * db
            if d < best_d:
                best_d = d
                best = c
        return best

    def nearest_n(self, rgb: tuple[int, int, int], n: int = 5) -> list[DMCColor]:
        r, g, b = rgb

        def dist(c: DMCColor) -> float:
            return (r - c.r) ** 2 + (g - c.g) ** 2 + (b - c.b) ** 2

        return sorted(self.colors, key=dist)[:n]

    def symbols_for(self, codes: Iterable[str]) -> dict[str, str]:
        glyphs = (
            "●○■□▲△◆◇★☆✚✕✚✱✲✳✴✵✶✷✸✹✺✻✼✽✾✿❀❁❂❃❄❅❆❇❈❉❊❋"
            "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            "αβγδεζηθικλμνξοπρστυφχψω"
            "абвгдежзийклмнопрстуфхцчшщъыьэюя"
        )
        mapping: dict[str, str] = {}
        i = 0
        for code in codes:
            mapping[code] = glyphs[i % len(glyphs)]
            i += 1
        return mapping
