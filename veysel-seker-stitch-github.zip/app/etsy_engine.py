"""Etsy listing copy (title, tags, description) generated locally."""

from __future__ import annotations

from pathlib import Path

from .pattern_engine import PatternResult


class EtsyEngine:
    def listing(self, pattern: PatternResult, title: str) -> dict:
        w_in, h_in = pattern.size_inches()
        w_cm, h_cm = pattern.size_cm()
        clean = title.strip() or "Cross Stitch Pattern"
        etsy_title = f"{clean} Cross Stitch Pattern PDF | {pattern.width}x{pattern.height} | {pattern.color_count} DMC | Instant Download"
        etsy_title = etsy_title[:140]
        tags = [
            "cross stitch pattern",
            "pdf pattern",
            "counted cross stitch",
            "dmc pattern",
            "instant download",
            "embroidery pattern",
            "needlepoint pdf",
            "modern cross stitch",
            "digital pattern",
            "diy wall art",
            "handmade gift",
            "hoop art",
            "aida 14",
        ]
        tags = [t[:20] for t in tags][:13]
        desc = f"""{clean} — counted cross stitch pattern (digital PDF).

WHAT YOU GET
• Printable PDF chart with symbols and 10-stitch bold grid
• Multi-page pagination with 3-row overlap
• Full DMC colour key ({pattern.color_count} colours)
• Mockup previews for listing / social
• Instant download after purchase

PATTERN DETAILS
• Stitch count: {pattern.width} × {pattern.height}
• Colours: {pattern.color_count} DMC stranded cotton
• Fabric: {pattern.aida}-count Aida (shown)
• Finished size on {pattern.aida}-ct: {w_in:.1f}\" × {h_in:.1f}\" ({w_cm:.1f} × {h_cm:.1f} cm)
• Total stitches: {pattern.stitch_count:,}

SKILL LEVEL
Confident beginner to intermediate. Full crosses only.

PLEASE NOTE
This is a digital item. No fabric or floss is included.
For personal use. Do not redistribute the PDF.

Designed with VEYSEL ŞEKER Pattern Studio (runs locally on your computer).
"""
        return {
            "title": etsy_title,
            "tags": tags,
            "description": desc,
            "price_hint_usd": 4.99,
            "category": "Craft Supplies & Tools > Patterns & How To > Patterns",
        }

    def write(self, pattern: PatternResult, title: str, out_path: str | Path) -> Path:
        data = self.listing(pattern, title)
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        tags = ", ".join(data["tags"])
        text = (
            f"TITLE\n{data['title']}\n\n"
            f"TAGS\n{tags}\n\n"
            f"CATEGORY\n{data['category']}\n\n"
            f"PRICE HINT\nUSD {data['price_hint_usd']:.2f}\n\n"
            f"DESCRIPTION\n{data['description']}\n"
        )
        out_path.write_text(text, encoding="utf-8")
        return out_path
